Wizard of NOS combined extraction package
=========================================

Generated from the uploaded Pass 10.66 index.html.

Upload/commit this package with the same folder structure:

  index.html
  styles/main.css
  planner/pass5-tetromino-planner.html
  vendor/three.r128.min.js
  data/nos-characters.js
  data/mushroom-field-sprites.js
  assets/mushrooms/mushroom-field-0.png
  assets/mushrooms/mushroom-field-1.png
  assets/mushrooms/mushroom-field-2.png
  ui/mini-planner-hud.js

Notes:
- This package includes the earlier Three.js extraction so it is self-contained.
- The planner iframe now loads planner/pass5-tetromino-planner.html.
- NOS character art/profile data is loaded from data/nos-characters.js.
- Mushroom field sprites are real PNG assets loaded through data/mushroom-field-sprites.js.
- CSS and the mini planner HUD script are external files.
- No intentional gameplay/default/localStorage/boot-order changes were made.
